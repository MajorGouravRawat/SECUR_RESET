package com.kanda.superlock;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText mEdit;
    // show number as a hint
    TextView showhint;
    // the index user chose to increment
    String userindex;
    // the latest password
    String passwordMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String password = "";

        //mButton = (Button)findViewById(R.id.button);
        mEdit   = findViewById(R.id.password);
        showhint = findViewById(R.id.lastnumber);



    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_ENTER) {

            //int random  = randomNumberGenerator();
            passwordMain = "1234";

            // lastNumber.setText(random);
            String incremented =  PIncrement( passwordMain,3 , 1);

            Integer passwordToCheck = permtion( mEdit.getText().toString(), incremented);


            Toast.makeText(this, passwordToCheck.toString(),
                    Toast.LENGTH_SHORT).show();




            return true;
        }
            else{
                return super.onKeyUp(keyCode, event);
            }

    }






    // swyew password
    // increment password and return.
    public String PIncrement(String password, int bucket, int increment){
        // array start form 0 so decrement the bucket.
        bucket -=1;
        // separet chr
        char[] passArray = password.toCharArray();
        int temp = 0;
        // take out incremeted bucket
        temp = (int)passArray[bucket] + increment;
        passArray[bucket] = (char)temp;

        return String.valueOf(passArray);
    }
    // user create passwords
//        public  void userSignUp(){
//            // user give as this info
//            System.out.println("Enter 4 diget Password");
//
//            System.out.println("select bucket");
//            System.out.println("select increment number 1 to 9");
//            //
//            //return bucket# and incremnt number
//        }
    // random number generator for the display
    public  int randomNumberGenerator(){

        int rNum = (int )(Math. random() * 9 + 1);
        // 9 is the maximum and the 1 is our minimum
        return rNum;
    }

    //password pass return 1 faill return 0
    public  int permtion(String EnteredPassword, String SavedPassword ){
        int passFail = 0;
        //compare new entered pasword and saved password
        if(EnteredPassword.equals(SavedPassword) ){
            passFail = 1;
        }
        return passFail;


    }


}
