package com.kanda.superlock;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class setting_activity extends AppCompatActivity {

    EditText newpassword;
    EditText confirmpassword;
    Button goback;
    Button setpassword;
    RadioButton whichindex;
    EditText increment;
    String[] data = new String[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_activity);

        newpassword = findViewById(R.id.newpassword);
        confirmpassword = findViewById(R.id.confirmpassword);
       // whichindex = findViewById(R.id.radiobutton);
        increment = findViewById(R.id.increment);
        goback = findViewById(R.id.goback);
        setpassword = findViewById(R.id.setpassword);

        // button on click listeners
        setpassword.setOnClickListener(setPasswordListener);


    }

    // make sure new password and confirm are the same if not toast error
    // if so, use intent to pass info and go to the next activity

    //

    private View.OnClickListener setPasswordListener = new View.OnClickListener() {
        public void onClick(View v) {
            // do something when the button is clicked
            // Yes we will handle click here but which button clicked??? We don't know

            // check string new password and confirm are the same
            String passwordData = comparePasswords();
            // get data and pass it to main activity
            data[0] = passwordData;
            data[1] = ;
            data[2] = increment.getText().toString();

        }
    };

}
